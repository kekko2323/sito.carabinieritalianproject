
document.getElementById("loginForm").addEventListener("submit", function(e) {
  e.preventDefault();
  const user = document.getElementById("username").value;
  const pass = document.getElementById("password").value;
  if(user === "carabiniere" && pass === "1234") {
    document.getElementById("loginStatus").innerText = "Accesso riuscito.";
  } else {
    document.getElementById("loginStatus").innerText = "Credenziali errate.";
  }
});

document.getElementById("segnalazioneForm").addEventListener("submit", function(e) {
  e.preventDefault();
  document.getElementById("segnalazioneStatus").innerText = "Segnalazione inviata. Grazie.";
});

const stazioni = ["Roma - Stazione Centro", "Milano - Stazione Duomo", "Napoli - Stazione Toledo"];
document.getElementById("cercaStazione").addEventListener("input", function() {
  const query = this.value.toLowerCase();
  const risultati = stazioni.filter(s => s.toLowerCase().includes(query));
  const lista = document.getElementById("risultatiStazioni");
  lista.innerHTML = "";
  risultati.forEach(st => {
    const li = document.createElement("li");
    li.textContent = st;
    lista.appendChild(li);
  });
});
